from flask import Flask, render_template
from datetime import datetime
import praw
import re
from collections import Counter
import logging
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import schedule
import time
import threading
from config import Config

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class RedditStockAnalyzer:
    def __init__(self):
        self.reddit = self._initialize_reddit_api()
        self.analyzer = SentimentIntensityAnalyzer()
        self.last_updated = None
        self.current_recommendations = []
        
    def _initialize_reddit_api(self):
        try:
            return praw.Reddit(
                client_id=Config.REDDIT_CLIENT_ID,
                client_secret=Config.REDDIT_CLIENT_SECRET,
                user_agent=Config.REDDIT_USER_AGENT
            )
        except Exception as e:
            logging.error(f"Error initializing Reddit API: {e}")
            return None

    def fetch_reddit_posts(self):
        all_posts = []
        try:
            for subreddit_name in Config.SUBREDDITS:
                subreddit = self.reddit.subreddit(subreddit_name)
                logging.info(f"Fetching posts from r/{subreddit_name}")
                for post in subreddit.hot(limit=Config.POST_LIMIT):
                    all_posts.append((post.title + " " + post.selftext))
            return all_posts
        except Exception as e:
            logging.error(f"Error fetching posts: {e}")
            return []

    def analyze_stocks(self):
        if not self.reddit:
            return []
            
        posts = self.fetch_reddit_posts()
        tickers = self._extract_stock_tickers(posts)
        recommendations = self._generate_recommendations(posts, tickers)
        self.last_updated = datetime.utcnow()
        self.current_recommendations = recommendations
        return recommendations

    def _extract_stock_tickers(self, posts):
        tickers = []
        ticker_pattern = re.compile(r'\b([A-Z]{2,4})\b')
        for post in posts:
            matches = ticker_pattern.findall(post)
            tickers.extend(matches)
        return tickers

    def _generate_recommendations(self, posts, tickers):
        ticker_counts = Counter(tickers)
        recommendations = []
        
        for ticker, count in ticker_counts.items():
            if count >= Config.MIN_MENTIONS:
                bull_count = 0
                bear_count = 0
                for post in posts:
                    if ticker in post:
                        sentiment_score = self.analyzer.polarity_scores(post)['compound']
                        if sentiment_score >= 0.05:
                            bull_count += 1
                        elif sentiment_score <= -0.05:
                            bear_count += 1
                recommendations.append((ticker, count, bull_count, bear_count))
        
        return sorted(recommendations, key=lambda x: x[1], reverse=True)

def create_app():
    app = Flask(__name__)
    analyzer = RedditStockAnalyzer()

    def update_recommendations():
        analyzer.analyze_stocks()

    @app.route("/")
    def home():
        if not analyzer.current_recommendations or not analyzer.last_updated:
            update_recommendations()
        
        return render_template(
            'index.html',
            recommendations=analyzer.current_recommendations,
            last_updated=analyzer.last_updated
        )

    # Start background thread for scheduled updates
    def run_schedule():
        schedule.every().day.at("00:00").do(update_recommendations)
        while True:
            schedule.run_pending()
            time.sleep(1)

    schedule_thread = threading.Thread(target=run_schedule, daemon=True)
    schedule_thread.start()

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=Config.DEBUG)