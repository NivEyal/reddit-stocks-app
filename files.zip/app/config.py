import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    # Reddit API Configuration
    REDDIT_CLIENT_ID = os.getenv('REDDIT_CLIENT_ID')
    REDDIT_CLIENT_SECRET = os.getenv('REDDIT_CLIENT_SECRET')
    REDDIT_USER_AGENT = os.getenv('REDDIT_USER_AGENT', 'News Stock Analysis (by u/Niv_Eyal)')
    
    # App Configuration
    DEBUG = os.getenv('DEBUG', 'False').lower() in ('true', '1', 't')
    SUBREDDITS = ['stocks', 'wallstreetbets', 'investing']
    MIN_MENTIONS = 5
    POST_LIMIT = 100