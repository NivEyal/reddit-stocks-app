# Reddit Stock Analysis App

A Flask web application that analyzes Reddit posts for stock recommendations using sentiment analysis.

## Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd stock_analysis_app
```

2. Create a virtual environment and activate it:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Create a `.env` file with your Reddit API credentials:
```
REDDIT_CLIENT_ID=your_client_id
REDDIT_CLIENT_SECRET=your_client_secret
REDDIT_USER_AGENT="News Stock Analysis (by u/YourUsername)"
DEBUG=False
```

5. Run the application:
```bash
python -m app.main
```

The application will be available at `http://localhost:5000`

## Deployment

To deploy to Heroku:

1. Create a Heroku account and install the Heroku CLI
2. Login to Heroku:
```bash
heroku login
```

3. Create a new Heroku app:
```bash
heroku create your-app-name
```

4. Set environment variables:
```bash
heroku config:set REDDIT_CLIENT_ID=your_client_id
heroku config:set REDDIT_CLIENT_SECRET=your_client_secret
heroku config:set REDDIT_USER_AGENT="News Stock Analysis (by u/YourUsername)"
```

5. Deploy the application:
```bash
git push heroku main
```

## Features

- Analyzes posts from r/stocks, r/wallstreetbets, and r/investing
- Performs sentiment analysis on mentions of stock tickers
- Updates recommendations daily at midnight
- Displays bullish and bearish mentions for each stock
- Shows rocket emojis for stocks with more bullish than bearish mentions

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.